USE [master]
GO

/****** Object:  Database [TP_SQL_Adventure_2017C1]    Script Date: 6/11/2016 10:46:22 AM ******/
CREATE DATABASE [TP_SQL_Adventure_2017C1]
GO

ALTER DATABASE [TP_SQL_Adventure_2017C1] SET ANSI_NULL_DEFAULT ON 
GO

ALTER DATABASE [TP_SQL_Adventure_2017C1] SET ANSI_NULLS ON
GO

ALTER DATABASE [TP_SQL_Adventure_2017C1] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [TP_SQL_Adventure_2017C1] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [TP_SQL_Adventure_2017C1] SET ARITHABORT OFF 
GO

ALTER DATABASE [TP_SQL_Adventure_2017C1] SET AUTO_CLOSE OFF 

USE [TP_SQL_Adventure_2017C1]
GO


/****** Object:  UserDefinedDataType [dbo].[Name]    Script Date: 6/11/2016 9:59:15 AM ******/
CREATE TYPE [dbo].[Name] FROM [nvarchar](50) NULL
GO

/****** Object:  UserDefinedDataType [dbo].[Flag]    Script Date: 6/11/2016 9:59:43 AM ******/
CREATE TYPE [dbo].[Flag] FROM [bit] NOT NULL
GO

CREATE SCHEMA Production
GO
